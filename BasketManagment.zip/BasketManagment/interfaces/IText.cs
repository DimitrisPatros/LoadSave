﻿namespace BasketManagment
{ 

    public interface IText
    {
        bool SaveText(string FileName);
        bool LoadText(string FileName);

    }
}
