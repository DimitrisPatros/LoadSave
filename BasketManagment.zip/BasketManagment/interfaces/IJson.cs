﻿

namespace BasketManagment
{
    public interface IJson
    {
        bool SaveJson(string FileName);
        bool LoadJson(string FileName);
    }
}

