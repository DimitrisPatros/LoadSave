﻿namespace BasketManagment
{
    public enum ProductCategoryId
    {
        Shirt = 1,
        Shoes = 2,
        Jeans = 3,
        Bags = 4
    }
}
